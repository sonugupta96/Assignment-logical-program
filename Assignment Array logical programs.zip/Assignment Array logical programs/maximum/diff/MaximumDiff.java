package com.maximum.diff;

public class MaximumDiff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//System.out.println("hello");
		
		int arr[]= {2, 5, 1, 7, 3, 9, 5};
		
		int max=arr[0];
		int min=arr[0];
		
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				max=arr[i];
				
			}else if(min>arr[i]) {
				
				min=arr[i];
			}
		}
		
		System.out.println("the maximum two element " +max+ " and "+min+" diff ="+(max-min));
	}

}
