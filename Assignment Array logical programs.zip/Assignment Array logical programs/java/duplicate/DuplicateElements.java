package com.java.duplicate;

import java.util.HashSet;
import java.util.Set;

public class DuplicateElements {


	public static void main(String[] args) {

		int arr[]= {1, 2, 5, 5, 6, 6, 7, 2};

		Set<Integer> set= new HashSet();

		for(int i=0; i<arr.length;i++)
		{
			if(set.add(arr[i])==false)
			{
				System.out.println("Duplicate:="+"{"+arr[i]+"}");

			}
		}

	}

}
