package com.min.max;

public class FindMinMaxElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("hello");

		int arr[]= {1, 2, 5, 5, 6, 6, 7, 2};

		int max=arr[0];
		int min=arr[0];

		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				max=arr[i];

			}else if(min>arr[i]) {

				min=arr[i];
			}
		}

		System.out.println("This is max="+max);
		System.out.println("this is min="+min);

	}

}
