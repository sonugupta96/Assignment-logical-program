package com.remove.duplicate;

import java.util.ArrayList;

public class RemoveDuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("hi Ashok IT");

		int arr[] = {1, 2, 5, 5, 6, 6, 7, 2};

		ArrayList a1=new ArrayList();

		for(int i=0; i<arr.length; i++)
		{
			if(a1.contains(arr[i])==false)
			{
				a1.add(arr[i]);
			}
		}
		System.out.println(a1);
	}

}
