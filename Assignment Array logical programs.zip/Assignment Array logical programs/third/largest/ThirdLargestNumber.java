package com.third.largest;

public class ThirdLargestNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[]= {6,8,6,4,10,11};
		int num=arr.length;
		if(num<3)
		{
			System.out.println("Invalid input");
			return;
		}

		int first=0;
		int second=0;
		int third =0;	

		for(int i:arr)
		{
			if(first<i)
			{
				third=second;
				second=first;
				first=i;
			}
			else if(second<i)
			{
				third=second;
				second=i;

			}else if(third<i) {
				third=i;
			}

		}


		System.out.println("third largest number is =" +third);
	}

}
