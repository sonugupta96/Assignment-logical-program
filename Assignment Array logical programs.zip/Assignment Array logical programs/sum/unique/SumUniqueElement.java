package com.sum.unique;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SumUniqueElement {

	public static void main(String[] args) {
		
		int arr[] = {1, 6, 4, 3, 2, 2, 3, 8, 1};
		List<Integer> list=new ArrayList<Integer>();
		for(int element:arr)
		{
			if(list.contains(element)==false)
			{
				list.add(element);
			}
		}
		System.out.println(list);
		System.out.println("Sum of unique="+sum(list));
	}
	public static int sum(List<Integer> list)
	{
		Iterator<Integer> it=list.iterator();
		int res=0;
		while(it.hasNext())
		{
			int num=it.next();
			res+=num;
		}
		return res;	
	}
}
